package com.khab.finalCheetBaat;

public interface SuperClassInterface {
    public String getName();

    public void setName(String name);

    public String getStatus();

    public void setStatus(String status);
}
